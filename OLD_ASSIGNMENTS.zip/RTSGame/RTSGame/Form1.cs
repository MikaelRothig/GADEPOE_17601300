﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RTSGame
{
    public partial class Form1 : Form
    {
        GameEngine engine = new GameEngine();

        public Form1()
        {
            InitializeComponent();
            btnStart.Enabled = true;
            btnPause.Enabled = false;
        }

        private void tmrGameTimer_Tick(object sender, EventArgs e)
        {
            
            lblTimer.Text = System.DateTime.Now.ToLongTimeString();
            engine.start();

            //SHOW GRID
            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.DialogResult result = MessageBox.Show("Do you want to save?", "Exit Game", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                engine.map.saveMap();
            }

            Application.Exit();

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.DialogResult result = MessageBox.Show("Do you want to load a saved game?", "Load Game", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                engine.map.loadMap();
            }
            else
            {
                engine.map.populate();
            }

            tmrGameTimer.Enabled = true;
            btnPause.Enabled = true;
            btnStart.Enabled = false;
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            tmrGameTimer.Enabled = false;
            btnPause.Enabled = false;
            btnStart.Enabled = true;
        }

        private void lblMap_Click(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int y = (mouseX - formX - 39 - 6) / 15;
            int x = (mouseY - formY - 70 - 1) / 15;

            txtInfo.Text = "";
            foreach (Unit u in engine.map.UnitsOnMap)
            {
                if (u.XPosition == x && u.YPosition == y)
                {
                    txtInfo.Text += u.toString();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tmrGameTimer.Enabled = false;
        }
    }
}
